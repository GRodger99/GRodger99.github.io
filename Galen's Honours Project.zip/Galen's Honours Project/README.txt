Hello!

This Project will Only run on Windows, and I have only Tested with Windows 10
so your experiance might change if you are using a different version.

You will also probably require some method of converting songs to a .wav format. A Common example would be Audacity. 


Ths project consists of two applications. An audio analysis application (WriteMyOwn) and the game application (Subconscious Grazer). 

The game application will run even if no audio analysis has been done, during this playthrough the game will default to shooting at 120 Beats per Minute and will have segments of 15 seconds long.

To run audio analysis please put a .wav file into the folder next to the WriteMyOwn application. Afterwards you can run WriteMyOwn and it will perform an analysis of the song.
Then you can run Subconcious Grazer again and it will play the game with that song and the gameplay should now be synced up.
Please note that if you are doing multiple different songs, to avoid any issues only have one .wav file in the folder.


Controls:
The Arrow Keys on your Keyboard are used to move the character around the screen.
Z - Will shoot bullets out from your character while held down.
Shift - can be use to Tighten up and focus your Fire forwards.
Escape - can be pressed During the game the instantly end the Game and take you to the end screen.

Features That this program usually works well with:

	A clear Beat (such as a kick Drum)
	A song with clear Sections
	~120 Beats Per Minute 
	A Consistant Tempo/speed
	
Styles that Generally work:
	
	Electronic Dance Music
	Standard Pop 

	


If you Encounter any issues feel free to contact me at nelag99@hotmail.com
or message me on LinkedIn.
Galen Rodger



 