First of all Thank you for partcipating!

Also if at any Point during the completion fo this survey you find yourself stuck or comfused, feel free to contact me.
I do not mind how you contact me (usually through the way you found the survey will be the best option!) 
My University email is "1701256@Abertay.ac.uk" if you would like to contact me that way!

This Project will Only run on Windows, i have only Tested with Windows 10
so your Experiance might change if you are using a different version.

You will also probably require some method of converting songs to a .wav format. A Common example would be Audacity. 

This project contains a "Bullet-Hell" style game where you control a small character and shoot at Enemies and Bosses 
to gain score while trying you best to dodge other bullets that the Enemies have fired at you.


Controls:
The Arrow Keys on your Keyboard are used to move the character around the screen.
Z - Will shoot bullets out from your character while held down.
Shift - can be use to Tighten up and focus your Fire forwards.
Escape - can be pressed During the game the instantly end the Game and take you to the end screen.

Upon opening the Project Folder you will see a few folders and a List of random files. 
The Two files You should focus on are the "Subconscious Grazer" File and the "writeMyOwn" file. 
Both of these are both of an "Application" file type.

Please do not close the game with escape for any of these test songs unless and issue occurs.
Let it play out till the end screen pops up then exit game.

Test 1: Base Game

Firstly i would like you to try the game without any of the Audio Analysis Features. 
I would like you to double click on the "Subconscious Grazer" file to run it. 
You Should see a small box open up asking how you would like to run the game. 
You can choose any settings here, but an Easy Setup would include just Ticking the "FullScreen" box and then hitting play
You should now see the main menu, where you simply press Play. 
Feel free to take some time to practice the controls and understand the game.


Please fill in the part of the form that asks about the "Base Game" now.  


Test 2: Song That should work

In this section i would like you to try use a song that should work. 
Please try and find a song that is Publically available 
Although any song is okay, try and not use a song longer than 5 minutes 
as the duration of the game is the length of the song

Please note that This will only analyse the first song in alphabetical order.
To avoid any issues, please ensure only 1 song is in the folder at a time.


Features That this program usually works well with:

	A clear Beat (such as a kick Drum)
	A song with clear Sections
	~120 Beats Per Minute 
	A Consistant Tempo/speed
	
Styles that Generally work:
	
	Electronic Dance Music
	Standard Pop 

After Finding a song that you think should work you will need to make sure this song is in wav format.
When your song is ready please put the song in the same folder that the other two 
important Files (Subconscious Grazer and writeMyOwn) are stored.

Then you will need to double-click the writeMyOwn file to run the audio analysis. 
It will pop up with command line box. You DO NOT need to do anything here. 
It will close itself after it has comepleted the audio analysis.
This shoudld take around ~10 seconds (This will change depending on the song and your computers hardware)

After this Simply run the Subconscious Grazer application again and it should now use your song.

Once finished Please fill out the next section of the survey.


Test 3: Song That Should Not Work

In this section I would like you do do the opposite from the previous section. 
Try and find a song that goes directly against the Features and Styles reccomended above.
The aim is to make the game struggle to understand/follow your music.

After Chosing the song remember to get it into a .wav format and repeat the steps you did during Test 2

Once you finish the playthough, Please fill out the next section of the survey.


Test 4: Completely Different Song

Here i would like you to try something completely different to the songs you use previously
This could be: 
	A song with a completely Different Tempo/Speed
	A song from a completely Different Genre
	A song with without/with vocals
	or a selection of the above
	(These are just a few ideas, anything you think makes the song different is okay!)
Hopefully these help you find a song you think fits into this category

And once again repeat the later stages of Task 2 To run Audio analysis and run the game.

Please continue on with the survey until you get to the final section which asks you to upload a file called Log.txt
This file can be found within the folder called "Subconscious Grazer_Data"
This folder will be in the same place as your song and the two other important Application files.
it should simply be called log and be a .txt (Text Document) file type.

And you are done! 
Thank you again and I hope you had fun!  

	





 